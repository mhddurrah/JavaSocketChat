# JavaSocketChat
Simple chat application with java sockets #netbeans-ide
