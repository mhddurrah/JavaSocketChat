/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package messages;

/**
 * when a non registered user tries to login this response will be returned to
 * indicate a request to register
 *
 * @author Olah
 */
public class DoRegister implements AuthMessage {

}
