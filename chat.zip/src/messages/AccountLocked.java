/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package messages;

/**
 * send to client to indicate that his/her account was locked because of
 * unsuccessful login tries
 *
 * @author Olah
 */
public class AccountLocked implements AuthMessage {

}
